/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package email;

import java.util.ArrayList;

/**
 *
 * @author Αριστείδης
 */
public class Account {
    private String username;//περιέχει το email του χρήστη.
    private String password;//περιέχει το κωδικό του χρήστη.
    private ArrayList<Email> emails;//Μια λίστα με τα email του χρήστη

    public Account(String name,String pass)
    {
        username=name;
        password=pass;
        emails=new ArrayList<>();
    }
    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param Password the password to set
     */
    public void setPassword(String Password) {
        this.password = Password;
    }

    /**
     * @return the emails
     */
    public ArrayList<Email> getEmails() {
        return emails;
    }

    /**
     * @param emails the emails to set
     */
    public void setEmails(ArrayList<Email> emails) {
        this.emails = emails;
    }
    
    
    
    
}
