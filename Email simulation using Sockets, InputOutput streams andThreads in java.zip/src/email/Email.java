/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package email;

import java.io.Serializable;

/**
 *
 * @author Αριστείδης
 */
public class Email implements Serializable{
    private String subject; //περιέχει το θέμα του μηνύματος.
    private String mainBody;//περιέχει το κύριο σώμα του μηνύματος.
    private boolean isNew;//περιέχει την πληροφορία αν το email έχει διαβαστεί.
    private String sender;//περιέχει το email του αποστολέα.
    private String receiver;//Όπου περιέχει το email του αποδέκτη.

    public Email(String sender,String receiver,String subject,String mainBody,boolean isNew)
    {
        this.sender=sender;
        this.receiver=receiver;
        this.subject=subject;
        this.mainBody=mainBody;
        this.isNew=isNew;
    }
    
    
    /**
     * @return the subject
     */
    public String getSubject() {
        return subject;
    }

    /**
     * @param subject the subject to set
     */
    public void setSubject(String subject) {
        this.subject = subject;
    }

    /**
     * @return the mainBody
     */
    public String getMainBody() {
        return mainBody;
    }

    /**
     * @param mainBody the mainBody to set
     */
    public void setMainBody(String mainBody) {
        this.mainBody = mainBody;
    }

    /**
     * @return the isNew
     */
    public boolean isIsNew() {
        return isNew;
    }

    /**
     * @param isNew the isNew to set
     */
    public void setIsNew(boolean isNew) {
        this.isNew = isNew;
    }

    /**
     * @return the sender
     */
    public String getSender() {
        return sender;
    }

    /**
     * @param sender the sender to set
     */
    public void setSender(String sender) {
        this.sender = sender;
    }

    /**
     * @return the receiver
     */
    public String getReceiver() {
        return receiver;
    }

    /**
     * @param Receiver the receiver to set
     */
    public void setReceiver(String Receiver) {
        this.receiver = Receiver;
    }
    
    
    public void showWholeEmail()// Εκτυπώνει όλα τα στοιχεία ενος email με μια συγκεκριμένη μορφή
    {
        System.out.println("Sender:   " + sender);
        System.out.println("");
        System.out.println("Subject:   " + subject);
        System.out.println("");
        System.out.println("Main body:   " + mainBody);
        System.out.println("");
    }
    
    
    
    public String toString()
    {
         String sen=sender;
         String sub=subject;
        if(sender.length()>6)        
              sen=sender.substring(0, 5);
        if(subject.length()>15)
            sub=subject.substring(0, 14);
        
        if(isNew==true)
            return "[new]  "+"    "+sen+"    "+sub;
        else
            return "       "+"    "+sen+"    "+sub;
    }
    
    
}
