package email;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;


/**
 *
 * @author Αριστείδης
 */
class Connection extends Thread implements Serializable {

    DataInputStream in;
    DataOutputStream out;
    ObjectInputStream inOb;
    ObjectOutputStream outOb;
    Socket clientSocket;
    HashMap<String, Account> allUsers;
    String username;
    String password;

    public Connection(Socket aClientSocket, HashMap<String, Account> allUsers) {
        try {
            this.allUsers = allUsers;
            clientSocket = aClientSocket;
            in = new DataInputStream(clientSocket.getInputStream());
            out = new DataOutputStream(clientSocket.getOutputStream());
            outOb = new ObjectOutputStream(clientSocket.getOutputStream());
            inOb = new ObjectInputStream(clientSocket.getInputStream());
            this.start();
        } catch (IOException e) {
            System.out.println("Connection:" + e.getMessage());
        }
    }

    public void run() {
        try {
            while (true) {
                int choice = in.readInt();
               // out.writeInt(choice);
                if (choice == 1) {   //Επιλογή 1 το login
                    username = in.readUTF();
                    password = in.readUTF();
                    Account a = login(username, password);
                    if (a == null) {
                        out.writeBoolean(false);
                    } else {
                        out.writeBoolean(true);
                    }
                    if (a != null) //
                    {
                        int answer;
                        do {
                            answer = in.readInt();
                            if (answer == 1) {//Eπιλογή 1 η δημιούργια νέου Εmail
                                String receiver = in.readUTF();
                                String subject = in.readUTF();
                                String mainbody = in.readUTF();
                                if (this.allUsers.containsKey(receiver)) {
                                    Email em = new Email(username, receiver, subject, mainbody, true);
                                    this.allUsers.get(receiver).getEmails().add(em);
                                    out.writeBoolean(true);
                                } else {
                                    out.writeBoolean(false);
                                }
                            } else if (answer == 2) {//Eπιλογή 2 η προβολή της λιστας με όλα τα Emails.
                                showAllEmails(out);
                            } else if (answer == 3) {//Eπιλογή 3 η προβολή ενός συγκεκριμένου Email.
                                showOneEmail(outOb, in);
                            } else if (answer == 4) {//Eπιλογή 4 η διαγραφή ενός συγκεκριμένου Email.
                                deleteEmail(out, in);
                            }
                        } while (answer != 5);

                    }
                } else if (choice == 2) { //Επιλογή 2 το signup
                    username = in.readUTF();
                    password = in.readUTF();
                    Account a = signup(username, password);
                    if (a == null) {
                        out.writeBoolean(false);
                    } else {
                        out.writeBoolean(true);
                    }
                    if (a != null) //
                    {
                        int answer;
                        do {
                            answer = in.readInt();
                            if (answer == 1) { //Eπιλογή 1 η δημιούργια νέου Εmail
                                String receiver = in.readUTF();
                                String subject = in.readUTF();
                                String mainbody = in.readUTF();
                                if (this.allUsers.containsKey(receiver)) {
                                    Email em = new Email(username, receiver, subject, mainbody, true);
                                    //System.out.println(em);
                                    this.allUsers.get(receiver).getEmails().add(em);
                                    out.writeBoolean(true);
                                } else {
                                    out.writeBoolean(false);
                                }
                            } else if (answer == 2) { //Eπιλογή 2 η προβολή της λιστας με όλα τα Emails.
                                showAllEmails(out);
                            } else if (answer == 3) { //Eπιλογή 3 η προβολή ενός συγκεκριμένου Email.
                                showOneEmail(outOb, in);
                            } else if (answer == 4) { //Eπιλογή 4 η διαγραφή ενός συγκεκριμένου Email.
                                deleteEmail(out, in);
                            }
                        } while (answer != 5);

                    }
                } else if (choice == 3) { //Επιλογή 3 στο exit.
                    return;
                }

            }
        } catch (EOFException e) {
            System.out.println("EOF:" + e.getMessage());
        } catch (IOException e) {
            System.out.println("readline:" + e.getMessage());
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {/*close failed*/

            }
        }

    }

    public Account login(String name, String password) { //Καλείται για να κάνει το login και επιστρέφει τον λογαριασμό αν 
        if (allUsers.containsKey(name)) {               //εχουν δοθεί σωστά στοιχεία, αλλιώς null.
            Account a = allUsers.get(name);
            if (a.getPassword().equals(password)) {
                return a;
            }
        }
        return null;

    }

    public Account signup(String name, String password) {//Καλείται για να κάνει το signup και επιστρέφει τον λογαριασμό αν 
        if (allUsers.containsKey(name)) {               //αν έχει ολοκληρωθεί σωστά η εγγραφή, αλλιώς null.
            return null;
        } else {
            allUsers.put(name, new Account(name, password));
        }
        return allUsers.get(name);
    }
        
    public void showAllEmails(DataOutputStream out) throws IOException { // Kαλείται για προβάλει όλα τα email του χρήστη.
        ArrayList<Email> emails = allUsers.get(username).getEmails();    //Γράφει με το DataOutputStream ένα string που είναι 
        if (emails.isEmpty()) {                                         //είναι μια λίστα με όλα emails.
            out.writeUTF("\n No messages \n");

        } else {
            StringBuilder sb = new StringBuilder("");
            int i = 1;
            sb.append("pid" + "      " + "     " + "  sender" + "     " + "subject \n");
            for (Email em : emails) {
                sb.append(i++ + ".    " + em.toString() + "\n");
            }
            sb.append("\n \n");
            String allEmails = sb.toString();
            out.writeUTF(allEmails);
        }

    }



    public void showOneEmail(ObjectOutputStream outOb, DataInputStream in) throws IOException {// Kαλείται για προβάλει ένα συγκεκριμένο email του χρήστη.
        int i = in.readInt();                                    //Διαβάζει από ενα  DataInputStream το id του email που θέλει 
        if (i > allUsers.get(username).getEmails().size()|| i<=0) {     // ο χρήστης να διαβάσει και γραφει ObjectOutputStream το email                      
            outOb.writeObject(null);                            //αυτό αν υπάρχει αλλιώς null.
            return;
        }
        i = i - 1;
        Email email = allUsers.get(username).getEmails().get(i);
        email.setIsNew(false);
        outOb.writeObject(email);
    }

    public void deleteEmail(DataOutputStream out, DataInputStream in) throws IOException {// Kαλείται για διαγράψει ένα συγκεκριμένο email του χρήστη.
        int i = in.readInt();                                                       //Διαβάζει από ενα  DataInputStream το id του email που θέλει 
        if (i > allUsers.get(username).getEmails().size()|| i<=0) {                        // ο χρήστης να διαγράψει και γράφει με ένα DataOutputStream
            out.writeBoolean(false);                                                //true ή false ανάλογα αν η διαγραφή ολοκληρώθηκε επιτυχώς.
            return;
        }
        i = i - 1;
        ArrayList<Email> emails = allUsers.get(username).getEmails();
        emails.remove(i);
        out.writeBoolean(true);
    }

}
