/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package email;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;


/**
 *
 * @author Αριστείδης
 */
public class Client implements Serializable{
  
     public Client(){
        
    }

        static String username;
        static String password;
    
        
    public static void main(String args[]) throws Throwable {
        // arguments supply message and hostname
        Socket s = null;
        try {
            int serverPort = Integer.parseInt(args[1]);
            s = new Socket(args[0], serverPort);
            DataInputStream in = new DataInputStream(s.getInputStream());
            DataOutputStream out = new DataOutputStream(s.getOutputStream());
            ObjectOutputStream outOb=new ObjectOutputStream(s.getOutputStream());
            ObjectInputStream inOb=new ObjectInputStream(s.getInputStream());
            Scanner sc = new Scanner(System.in);
            int answer = 0;
           // int check_answer;
            while (true) {
                boolean flag = true;
                do {
                    System.out.println("Hello \n"); //Εμφάνιση αρχικού μενού.
                    System.out.println("1. LogIn");
                    System.out.println("2. SignUp");
                    System.out.println("3. Exit");
                    try {
                        //answer=sc.nextInt();
                        answer = sc.nextInt();
                        if (answer > 0 && answer < 4) {
                            flag = false;
                        } else {
                            System.out.println("Choose 1 or 2 or 3");
                        }
                    } catch (Exception e) {
                        System.out.println("Choose 1 or 2 or 3.");
                        sc.nextLine();
                    }

                } while (flag);
                out.writeInt(answer);
               // check_answer = in.readInt();
                if (answer == 1) { //Η επιλογή 1, ο χρήστης κάνει login και έπειτα του εμφανίζεται ένα μενού επιλογών(newEmail, showEmail κτλ)
                    boolean isOk = login(out, in);
                    if (isOk) {
                        System.out.println("");
                        System.out.println("You are connect as " + username);
                        int i = showmenu(out, in, outOb, inOb);
                        if (i == 0) {
                            return;
                        }
                    } else {
                        System.out.println("Wrong username or password");
                    }
                } else if (answer == 2) {//Η επιλογή 2, ο χρήστης κάνει sign και έπειτα του εμφανίζεται ένα μενού επιλογών(newEmail, showEmail κτλ)
                    boolean allOk = signup(out, in);
                    if (allOk) {
                        System.out.println("Your registration is complete");
                        System.out.println("You are connect as " + username);
                        int i = showmenu(out,in,outOb,inOb);
                        if(i==0)
                        {
                            return;
                        }
                    }
                    else
                    {
                         System.out.println("This username is already exist");
                    }

                } else if (answer == 3) { //Ο χρήστης ζητάει τον τερματισμό της εφαρμογής.
                     return;
                } else {
                    System.out.println("something goes wrong");
                }

            }
            
		}catch (UnknownHostException e){System.out.println("Socket:"+e.getMessage());
		}catch (EOFException e){System.out.println("EOF:"+e.getMessage());
		}catch (IOException e){System.out.println("readline:"+e.getMessage());
		}finally {if(s!=null) try {s.close();}catch (IOException e){System.out.println("close:"+e.getMessage());}}
     }
		
        
     
    public static boolean login(DataOutputStream out, DataInputStream in) throws IOException {//H συνάρτηση αυτή καλείται για το login.
        boolean isOk = false;                           //Δίνει στο connection (thread του server) τον email
        Scanner sc = new Scanner(System.in);            //και τον κωδικό που έδωσε ο χρήστης και εκείνο επιστρέφει true ή false 
        do {                                            //ανάλογα με το αν έγινε είσοδος.
            System.out.println("Give email");
            username = sc.nextLine();
        } while (username.length() < 2);

        do {
            System.out.println("Give password");
            password = sc.nextLine();
        } while (password.length() < 2);
        out.writeUTF(username);
        out.writeUTF(password);
        isOk = in.readBoolean();
        return isOk;
    }
    
    
        public static boolean signup(DataOutputStream out, DataInputStream in) throws IOException {//H συνάρτηση αυτή καλείται για το signup.
        boolean allOk;                                //Δίνει στο connection (thread του server) τον email
        Scanner sc = new Scanner(System.in);          //και τον κωδικό που έδωσε ο χρήστης και εκείνο επιστρέφει true ή false                                  
        boolean f=true;                               //ανάλογα με το αν έγινε εγγραφή.
        do {
            System.out.println("Give email");
            username = sc.nextLine();
            if((username.length() < 2)||(!(username.contains("@"))))
            {
                System.out.println("Please give a valid email");
            }else
            {
                f=false;
            }
        } while (f);

        do {
            System.out.println("Give password");
            password = sc.nextLine();
        } while (password.length() < 2);
        out.writeUTF(username);
        out.writeUTF(password);
        allOk = in.readBoolean();
        return allOk;
    }

    public static int showmenu(DataOutputStream out,DataInputStream in,ObjectOutputStream outOb,ObjectInputStream inOb) throws IOException, Throwable {
        int ans = 0;                            //H συνάρτηση αυτή καλείται για την προβολή ενός μενού στον χρήστη μετά την σύνδεση του. 
        Scanner sc = new Scanner(System.in);    //Ο χρήστης επιλέγει κάτι από αυτό το μενού και εκλτελειται η αντίστοιχη ενεργεια.   
        do {
            boolean f = true;
            do {
                System.out.println("1. NewEmail");
                System.out.println("2. ShowEmails");
                System.out.println("3. ReadEmail");
                System.out.println("4. DeleteEmail");
                System.out.println("5. LogOut");
                System.out.println("6. Exit");
                try {
                    ans = sc.nextInt();
                    if (ans > 0 && ans < 7) {
                        f = false;
                    } else {
                        System.out.println("Choose something between 1 and 6.");
                    }
                } catch (Exception e) {
                    System.out.println("Choose something between 1 and 6.");
                    sc.nextLine();
                }
            } while (f);
            out.writeInt(ans);
            if (ans == 1) {
                newEmail(out,in);
            } else if (ans == 2) {
                 showEmails(in);
            } else if (ans == 3) {
                 showOneEmail(out, inOb);
            } else if (ans == 4) {
                deleteEmail(out, in);
            } else if (ans == 6) {
                return 0;
            }
        } while (ans != 5);
        return 1;
    }
        
        
    public static void newEmail(DataOutputStream out,DataInputStream in)throws IOException
    {                                                       //H συνάρτηση αυτή καλείται όταν ο χρήστης θέλει να συντάξει ένα νέο email.
        Scanner sc=new Scanner(System.in);
        String mainbody;
        String receiver;
        String subject;
       do {
            System.out.println("Give the name of the receiver: ");
            receiver = sc.nextLine();
        } while (receiver.length() < 2);
        do {
            System.out.println("Write the subject of the email: ");
            subject = sc.nextLine();
        } while (subject.length() < 2);
        do {            
            System.out.println("Write the main body : ");
            mainbody = sc.nextLine();
        } while (mainbody.length() < 2);
        
        out.writeUTF(receiver);
        out.writeUTF(subject);
        out.writeUTF(mainbody);
        boolean mailhassented=in.readBoolean();
        if(mailhassented==true)
        {
            System.out.println("Mail sent successfully");
        }
        else{
            System.out.println("Receiver not exist.Please try again");
        }
    }    
        
    public static void showEmails(DataInputStream in)throws Throwable{
        String all=in.readUTF();
        System.out.println(all);
        
    }
        
    public static void showOneEmail(DataOutputStream out,ObjectInputStream inOb) throws IOException, ClassNotFoundException
    {                                           //H συνάρτηση αυτή καλείται όταν ο χρήστης θέλει να δει ένα συγκεκριμένο email.
        Scanner sc=new Scanner(System.in);
        System.out.println("give the id of the email that you want to read");
        int i=0;
        boolean f=true;
         do{     
             String number=sc.nextLine();
            try {
                i = Integer.parseInt(number);
            f=false;
        } catch (Exception e) {
            System.out.println("Write the id of someone email");
        }
        }while(f);
        out.writeInt(i);
        Email email=(Email)inOb.readObject();
        if (email != null) {
            email.showWholeEmail();
        }else
            System.out.println("This id is not exist");
    }
    
    public static void deleteEmail(DataOutputStream out,DataInputStream in) throws IOException
    {                                               //H συνάρτηση αυτή καλείται όταν ο χρήστης θέλει να διαγράψει ένα συγκεκριμένο email.
        Scanner sc = new Scanner(System.in);
        System.out.println("give the id of the email that you want to delete");
        int i = 0;
        boolean f = true;
        do {
            String number=sc.nextLine();
            try {
                i = Integer.parseInt(number);
                f = false;
            } catch (Exception e) {
                System.out.println("Write the id of someone email");
            }
        } while (f);
        out.writeInt(i);
        boolean isDeleted=in.readBoolean();
        if(isDeleted)
        {
            System.out.println("The email is deleted");
        }else
        {
            System.out.println("This id is not exist");
        }
    }

        
        
    
    }
   
    

