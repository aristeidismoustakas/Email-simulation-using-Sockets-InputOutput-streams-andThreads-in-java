/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package email;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

/**
 *
 * @author Αριστείδης
 */
public class Server {

    static HashMap<String, Account> allUsers = new HashMap<>();

    public static void main(String args[]) {
            // Προσθήκη 2 λογαριασμών και προσθήκη 2 μηνυμάτων σε κάθε λογαριασμό.
            allUsers.put("aris@gmail.com", new Account("aris@gmail.com", "1234"));
            allUsers.put("maria@gmail.com", new Account("maria@gmail.com", "123"));
            allUsers.get("aris@gmail.com").getEmails().add(new Email( "maria@gmail.com","aris@gmail.com", "subject_ar_1111", "main_body_aris_1111", true));
            allUsers.get("aris@gmail.com").getEmails().add(new Email("maria@gmail.com","aris@gmail.com", "subject_ar_2222", "main_body_aris_2222", true));
            allUsers.get("aris@gmail.com").getEmails().add(new Email("maria@gmail.com","aris@gmail.com", "subject_ar_3333", "main_body_aris_3333", true));
            allUsers.get("maria@gmail.com").getEmails().add(new Email("aris@gmail.com", "maria@gmail.com", "subject_mar_1111", "main_body_mary_1111", true));
            allUsers.get("maria@gmail.com").getEmails().add(new Email("aris@gmail.com", "maria@gmail.com", "subject_mar_2222", "main_body_mary_2222", true));
            allUsers.get("maria@gmail.com").getEmails().add(new Email("aris@gmail.com", "maria@gmail.com", "subject_mar_3333", "main_body_mary_3333", true));
        
            try {
            int serverPort = Integer.parseInt(args[0]);; // the server port
            ServerSocket listenSocket = new ServerSocket(serverPort);
            while (true) {
                Socket clientSocket = listenSocket.accept();

                System.out.println("Request from client" + clientSocket.getInetAddress() + "at port " + clientSocket.getPort());
                Connection c = new Connection(clientSocket, allUsers);
            }
        } catch (IOException e) {
            System.out.println("Listen socket:" + e.getMessage());
        }
    }

}
